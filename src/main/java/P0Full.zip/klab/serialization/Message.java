package klab.serialization;

import java.io.IOException;

public class Message {

    Message(byte[] msgID, int ttl, RoutingService routingService) throws BadAttributeValueException{

    }

    public void encode(MessageOutput out) throws IOException {

    }

    public void decode(MessageInput in) throws IOException, BadAttributeValueException {

    }

    public int getMessageType() {
        return 0;
    }

    public byte[] getID() {
        return null;
    }

    public Message setID(byte[] id) {
        return null;
    }

    public int getTTL() {
        return 0;
    }

    public Message setTTL(int ttl) throws BadAttributeValueException {
        return null;
    }

    public RoutingService getRoutingService() {
        return null;
    }

    public Message setRoutingService(RoutingService routingService) throws BadAttributeValueException{
        return null;
    }
}
