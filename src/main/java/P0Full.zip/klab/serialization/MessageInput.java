package klab.serialization;


import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Deserialization input source This should ONLY include general methods for parsing. Do not include protocol-specific
 * methods; those should be in the protocol-specific classes.
 *
 * @version 1.0
 */
public class MessageInput {
    private static final byte DELIM = '\n';
    private DataInputStream in;

    /**
     * Constructs a new input source from an InputStream
     *
     * @param in - byte input source
     * @throws NullPointerException if it is null
     */

    public MessageInput(InputStream in) throws NullPointerException, IOException {
        if (in == null) {
            throw new NullPointerException("InputStream is null");
        }
        this.in = new DataInputStream(in);
    }



    public byte[] read4bytes() throws IOException {
        byte b[] = new byte[4];

        for (int i = 0; i < 4; i++) {
            b[i] = (byte) in.read();
        }
        return b;
    }


    /**
     * read an unsigned int from inputStream
     *
     * @return - long representing a unsigned int
     */



    public long readUnsignedInt() throws IOException {
        long l = 0;
        for (int i = 0; i < 4; i++) {
            l |= (in.read() & 0xFFL) << (24 - (i * 8));
        }
        return l;
    }


    /**
     * read a string from inputStream
     *
     * @return - String read from buffer
     */


    public String readString() throws IOException, BadAttributeValueException {
        ByteArrayOutputStream buff = new ByteArrayOutputStream();
        int nextByte;

        while ((nextByte = in.read()) != DELIM) {
            if (nextByte == -1) {
                throw new IOException("Premature end of stream");
            }
            buff.write(nextByte);
        }
        return buff.toString(StandardCharsets.US_ASCII.name());
    }


    /**
     * checks if MessageInput int array is empty
     *
     * @return - true if messageIn is empty
     */


    public int size() throws IOException {
        return in.available();
    }

}
