package klab.serialization;

import java.net.InetSocketAddress;
import java.util.List;

public class Response extends Message{

    public Response(byte[] msgID, int ttl, RoutingService routingService, InetSocketAddress responseHost) throws BadAttributeValueException{
        super(msgID, ttl, routingService);
    }

    public String toString() {
        return null;
    }

    public InetSocketAddress getResponseHost() {
        return null;
    }

    public Response setResponseHost(InetSocketAddress responseHost) throws BadAttributeValueException {
        return null;
    }

    public List<Result> getResultList() {
        return null;
    }

    public Response addResult(Result result) throws BadAttributeValueException {
        return null;
    }

}
