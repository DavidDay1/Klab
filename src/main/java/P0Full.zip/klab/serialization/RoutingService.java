package klab.serialization;

public enum RoutingService {
    BreadthFirst,
    DEPTHFIRST;


    private RoutingService() {
    }

    //public static RountingService[] values() {
    //    return null;
    //}


    public int getCode() {
        return 0;
    }

    public static RoutingService getRoutingService(int code) throws BadAttributeValueException {
        return null;
    }


}
