package klab.serialization;

public class Search extends Message {

    public Search(byte[] msgID, int ttl, RoutingService routingService, String searchString) throws BadAttributeValueException{
        super(msgID, ttl, routingService);
    }

    public String toString() {
        return null;
    }

    public String getSearchString() {
        return null;
    }

    public Search setSearchString(String searchString) throws BadAttributeValueException {
        return null;
    }
}
