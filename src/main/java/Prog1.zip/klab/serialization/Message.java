package klab.serialization;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Objects;

/**
 * Represents a response message
 * @version 1.0
 */
public class Message {
    private static final byte DELIM = '\n'; //Delimiter to determine end of a stream
    protected int type; //the type of message 1 = search and 2 = response
    protected byte[] msgID; //id of the message
    protected int ttl; //time to live of the message
    protected RoutingService routingService; //The routing service used either DepthFirst or BreadthFirst
    protected int length; //The length of the message payload
    protected byte[] payload; //the message payload

    /**
     * Constructs base message with given values
     * @param msgID message ID
     * @param ttl message ttl
     * @param routingService message routing service
     * @throws BadAttributeValueException if any parameter fails validation
     */

    Message(byte[] msgID, int ttl, RoutingService routingService) throws BadAttributeValueException{
        setID(msgID);
        setTTL(ttl);
        setRoutingService(routingService);
    }

    /**
     * Encode message to given output sink
     * @param out output sink
     * @throws IOException if I/O problem or out is null
     */

    public void encode(MessageOutput out) throws IOException {
        if (out == null) {
            throw new IOException("MessageOutput is null");
        }
        out.write(type);
        out.write(msgID);
        out.write(ttl);
        out.write(routingService.getCode());
        out.writeShort(length);
        out.write(payload);
    }

    /**
     * Deserializes message from input source
     * @param in deserialization input source
     * @return a specific message resulting from deserialization
     * @throws IOException if in is null or I/O problem occurs
     * @throws BadAttributeValueException if any parsed value fails validation
     */

    public static Message decode(MessageInput in) throws IOException, BadAttributeValueException {
        if (in == null || in.size() < 20) {
            throw new IOException("MessageInput is null or too short");
        }

        int type = in.read();
        byte[] id = new byte[15];
        in.readFully(id);
        int ttl = in.read();
        int routingService = in.read();
        RoutingService rs = RoutingService.getRoutingService(routingService);
        int payloadLength = in.readUnsignedShort();
        if (in.size() < payloadLength) {
            throw new IOException("Payload does not match given length");
        }
        byte[] payload;

        if (type == 1) {
            payload = in.readBytes(payloadLength);
            return new Search(id, ttl, rs, new String(payload));
        } else if (type == 2) {
            ByteArrayOutputStream payloadStream = new ByteArrayOutputStream();
            
            int matches = in.read();
            payloadStream.write(matches);

            int port = in.readUnsignedShort();
            payloadStream.write(ByteBuffer.allocate(2).putShort((short) port).array());

            byte[] address = in.read4bytes();
            payloadStream.write(address);
            InetAddress addr =  InetAddress.getByAddress(address);


            Response r = new Response(id, ttl, rs, new InetSocketAddress(addr, port));
            r.matches = matches;
            r.length = payloadLength;

            for (int i = 0; i < matches; i++) {
                byte[] fileID = in.read4bytes();
                payloadStream.write(fileID);

                long fileSize = in.readUnsignedInt();
                byte[] fileSizeBytes = ByteBuffer.allocate(4).putInt((int) fileSize).array();
                payloadStream.write(fileSizeBytes);

                String fileName = in.readString();
                payloadStream.write(fileName.getBytes(StandardCharsets.US_ASCII));
                payloadStream.write(DELIM);

                r.addResult(new Result(fileID, fileSize, fileName));
            }
            r.payload = payloadStream.toByteArray();
            return r;
        }  else {
            throw new BadAttributeValueException("Invalid message type", "type");
        }
    }

    /**
     * Return the message type code (from protocol)
     * @return message type code (from protocol)
     */

    public int getMessageType() {
        return type;
    }

    /**
     * Get ID
     * @return ID of message
     */

    public byte[] getID() {
        return msgID;
    }

    /**
     * Set ID
     * @param id new ID
     * @return this Message with new ID
     */

    public Message setID(byte[] id) throws BadAttributeValueException {
        if (id == null) {
            throw new BadAttributeValueException("id is null", "id");
        }else if (id.length != 15) {
            throw new BadAttributeValueException("id is not correct length", "id");
        } else {
            this.msgID = id;
            return this;
        }
    }

    /**
     * Get TTL
     * @return TTL of message
     */

    public int getTTL() {
        return ttl;
    }

    /**
     * Set TTL
     * @param ttl new TTL
     * @return this Message with new TTL
     * @throws BadAttributeValueException if ttl is invalid
     */

    public Message setTTL(int ttl) throws BadAttributeValueException {
        if (ttl < 0 || ttl > 255) {
            throw new BadAttributeValueException("ttl is invalid", "ttl");
        } else {
            this.ttl = ttl;
            return this;
        }
    }


    /**
     * Get routing service
     * @return routing service
     */

    public RoutingService getRoutingService() {
        return routingService;
    }

    /**
     * Set routing service
     * @param routingService new routing service
     * @return this Message with new routing service
     * @throws BadAttributeValueException if routingService is null
     */

    public Message setRoutingService(RoutingService routingService) throws BadAttributeValueException{
        if (routingService == null) {
            throw new BadAttributeValueException("routingService is null", "routingService");
        } else {
            this.routingService = routingService;
            return this;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Message message)) return false;
        return ttl == message.ttl && Arrays.equals(msgID, message.msgID) && routingService == message.routingService;
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(ttl, routingService);
        result = 31 * result + Arrays.hashCode(msgID);
        return result;
    }
}
