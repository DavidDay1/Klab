package klab.serialization;


import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Deserialization input source This should ONLY include general methods for parsing. Do not include protocol-specific
 * methods; those should be in the protocol-specific classes.
 *
 * @version 1.0
 */


public class MessageInput {
    private static final byte DELIM = '\n'; //Delimiter to determine end of a stream
    private DataInputStream in; // Input Stream to read from

    /**
     * Constructs a new input source from an InputStream
     *
     * @param in byte input source
     * @throws NullPointerException if it is null
     */

    public MessageInput(InputStream in) throws NullPointerException, IOException {
        if (in == null) {
            throw new NullPointerException("InputStream is null");
        }
        this.in = new DataInputStream(in);
    }



    public byte[] read4bytes() throws IOException {
        byte b[] = new byte[4];

        for (int i = 0; i < 4; i++) {
            b[i] = (byte) in.read();
        }
        return b;
    }


    /**
     * read an unsigned int from inputStream
     *
     * @return long representing a unsigned int
     */



    public long readUnsignedInt() throws IOException {
        long l = 0;
        for (int i = 0; i < 4; i++) {
            l |= (in.read() & 0xFFL) << (24 - (i * 8));
        }
        return l;
    }


    /**
     * read a string from inputStream
     *
     * @return String read from buffer
     */


    public String readString() throws IOException, BadAttributeValueException {
        ByteArrayOutputStream buff = new ByteArrayOutputStream();
        int nextByte;

        while ((nextByte = in.read()) != DELIM) {
            if (nextByte == -1) {
                throw new IOException("Premature end of stream");
            }
            buff.write(nextByte);
        }
        return buff.toString(StandardCharsets.US_ASCII.name());
    }


    public int read() throws IOException {
        return in.read();
    }

    public void readFully(byte[] b) throws IOException {
        if (in.read(b) != b.length) {
            throw new IOException("Premature end of stream");
        }
    }

    public int readUnsignedShort() throws IOException {
        int b1 = in.read();
        int b2 = in.read();
        if ((b1 | b2) < 0) {
            throw new IOException("Premature end of stream");
        }
        return (b1 << 8) + (b2 << 0);
    
    }

    public byte[] readBytes(int length) throws IOException {
        byte[] b = new byte[length];
        for (int i = 0; i < length; i++) {
            b[i] = (byte) in.read();
        }
        return b;
    }


    /**
     * checks if MessageInput int array is empty
     *
     * @return true if messageIn is empty
     */


    public int size() throws IOException {
        return in.available();
    }

}
