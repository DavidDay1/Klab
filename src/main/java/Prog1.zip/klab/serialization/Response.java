package klab.serialization;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * Represents a response message
 * @version 1.0
 */

public class Response extends Message{
    private InetSocketAddress responseHost; //address and port of the host
    protected int matches; //number of results
    private List<Result> resultList; //individual results

    /**
     * Constructs Response from given attributes
     * @param msgID message ID
     * @param ttl message ttl
     * @param routingService message routing service
     * @param responseHost Address and port of responding host
     * @throws BadAttributeValueException if bad or null attribute value
     */

    public Response(byte[] msgID, int ttl, RoutingService routingService, InetSocketAddress responseHost) throws BadAttributeValueException{
        super(msgID, ttl, routingService);
        setResponseHost(responseHost);
        this.resultList = new ArrayList<>(matches);
        this.type = 2;
    }


    /**
     * Returns a String representation
     * @return String representation
     */

    @Override
    public String toString() {
        StringBuilder responseString = new StringBuilder("Response: ID=");
        for (int i = 0; i < this.msgID.length; i++) {
            responseString.append(String.format("%02X", this.msgID[i]));
        }
        responseString.append(" TTL=" + this.ttl + " Routing=" + this.routingService + " " +
                "Host=" + responseHost.getAddress().getHostAddress() + ':' + responseHost.getPort() + " [");
        for (Result result : resultList) {
            responseString.append(result.toString());
            if (resultList.indexOf(result) != resultList.size() - 1) {
                responseString.append(", ");
            }
        }
        responseString.append("]");
        return responseString.toString();
    }

    /**
     * Get address and port of responding host
     * @return responding host address and port
     */

    public InetSocketAddress getResponseHost() {
        return responseHost;
    }

    /**
     * Set address and port of responding host
     * @param responseHost responding host address and port
     * @return this Response with new response host
     * @throws BadAttributeValueException if responseHost is null or if the address is 1) multicast or 2) not IPv4
     * address
     */

    public Response setResponseHost(InetSocketAddress responseHost) throws BadAttributeValueException {
        if (responseHost == null || responseHost.getAddress().isMulticastAddress() || !(responseHost.getAddress() instanceof Inet4Address)) {
            throw new BadAttributeValueException("responseHost ", "responseHost is not a valid unicast address");
        } else {
            this.responseHost = responseHost;
            return this;
        }
    }


    /**
     * Get list of results
     * @return result list
     */

    public List<Result> getResultList() {
        if (resultList == null) {
            return null;
        } else {
            return resultList;
        }
    }

    /**
     * add result to list
     * @param result new result to add to result list
     * @return this Response with new result added
     * @throws BadAttributeValueException if result is null or would make result list too long to encode
     */

    //check if encoding is too long
    public Response addResult(Result result) throws BadAttributeValueException {
        if (result == null || this.resultList.size() == 255 ){
            throw new BadAttributeValueException("result is null", "result");
        } else {
            this.resultList.add(result);
            return this;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Response response)) return false;
        return ttl == response.ttl && Arrays.equals(msgID, response.msgID) 
        && routingService == response.routingService
        && length == response.length
        && responseHost.equals(response.responseHost)
        && resultList.size() == response.resultList.size() 
        && resultList.equals(response.resultList);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(ttl, routingService, responseHost, length, resultList);
        result = 31 * result + Arrays.hashCode(msgID);
        return result;
    }
}
