package klab.serialization;

import java.util.Arrays;
import java.util.Objects;

/**
 * Represents a search message
 * @version 1.0
 */

public class Search extends Message {
    private String searchString; //string to search for

    public Search(byte[] msgID, int ttl, RoutingService routingService, String searchString) throws BadAttributeValueException{
        super(msgID, ttl, routingService);
        setSearchString(searchString);
        this.length = searchString.length();
        this.payload = searchString.getBytes();
        this.type = 1;
    }

    public String toString() {
        StringBuilder responseString = new StringBuilder("Search: ID=");
        for (int i = 0; i < this.msgID.length; i++) {
            responseString.append(String.format("%02X", this.msgID[i]));
        }
        responseString.append(" TTL=" + this.ttl + " Routing=" + this.routingService + " " +
                "Search=" + searchString);
        return responseString.toString();
    }

    public String getSearchString() {
        return searchString;
    }

    public Search setSearchString(String searchString) throws BadAttributeValueException {
        if (searchString == null || searchString.length() > 65535) {
            throw new BadAttributeValueException("searchString is null or too big", "searchString");
        }
        for (int i = 0; i < searchString.length(); i++) {
            if (!Character.isLetterOrDigit(searchString.charAt(i)) && searchString.charAt(i) != '.' && searchString.charAt(i) != '_' && searchString.charAt(i) != '-') {
                throw new BadAttributeValueException("searchString contains non-ASCII characters", "searchString");
            }
        }
        this.searchString = searchString;
        this.length = searchString.length();
        this.payload = searchString.getBytes();
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Search search)) return false;
        return ttl == search.ttl && Arrays.equals(msgID, search.msgID) 
            && routingService == search.routingService
            && length == search.length
            && searchString.equals(search.searchString);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(ttl, routingService, searchString);
        result = 31 * result + Arrays.hashCode(msgID);
        return result;
    }
}
