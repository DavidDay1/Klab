package klab.app;

public class Node {
    private String ohnobro = "I am doomed!";
}
